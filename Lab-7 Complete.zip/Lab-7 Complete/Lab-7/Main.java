class Main {
  public static void main(String[] args) {


  String[] vertices = {"Liberal Arts", "Student Services", 
  "Health Careers & Sciences", "Health Technologies Center", 
  "Recreation Center", "Technology Learning Center", 
  "Business & Technology", "Theatre"}; 
  
  int[][] edges = { 
    {0, 1}, {1, 0},
    {0, 7}, {7, 0},
    {1, 2}, {2, 1},
    {1, 5}, {5, 1},
    {2, 3}, {3, 2},
    {2, 4}, {4, 2},
    {4, 5}, {5, 4},
    {5, 6}, {6, 5},
    {6, 7}, {7, 6}
  };

UnweightedGraph<String> campusGraph = new UnweightedGraph<>(vertices, edges);

UnweightedGraph<String>.SearchTree dfs = campusGraph.dfs(campusGraph.getIndex("Business & Technology"));


java.util.List<Integer> searchOrders = dfs.getSearchOrder();
System.out.println("Search Order: ");
    for (int i = 0; i < searchOrders.size(); i++)
    System.out.print(campusGraph.getVertex(searchOrders.get(i)) + " ");
    System.out.println();

 for (int i = 0; i < searchOrders.size(); i++)
  if (dfs.getParent(i) != -1)
  System.out.println("Parent of " + campusGraph.getVertex(i) +
  " is: " + campusGraph.getVertex(dfs.getParent(i)));

dfs.printPath(3);
dfs.printPath(1);
dfs.printPath(4);
  
dfs.printTree();
  }
  
  }
